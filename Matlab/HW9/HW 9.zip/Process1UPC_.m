function [nanNumber, compValue, NewNaNs] = Process1UPC_(RowReplace)
    [nanNumber, theSum, nanIdx] = FindNaNandSum1UPC_(RowReplace);
    if nanNumber == 1
        compValue = Fix1UPC_(theSum, nanIdx);
        RowReplace(nanIdx) = compValue;
        NewNaNs = RowReplace;
    else
        compValue = 0; 
        NewNaNs = 0;
    end
end


