function [nanNumber, theSum, nanIdx] = FindNaNandSum1UPC_(RowReplace)
    nanNumber = nnz(isnan(RowReplace));
    if nanNumber == 1
        nanIdx = find(isnan(RowReplace));
        RowReplace(nanIdx) = 0;
        theSum = (sum(RowReplace(1:2:end))*3 + sum(RowReplace(2:2:end)));
    else 
        theSum = 0;
        nanIdx = 0;
    end
end


