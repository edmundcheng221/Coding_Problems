%% Problem 1
clear; clc; format short;
ORIGINAL = [7 2 2 8 3 5 7 9 0 1 4 6
NaN 2 2 8 3 5 7 9 0 1 4 6
7 2 2 8 3 5 7 9 0 1 4 NaN
7 2 2 8 3 NaN NaN 9 NaN 1 4 6
7 2 2 8 3 5 NaN 9 0 1 4 NaN
2 8 3 5 7 9 0 1 4 6 NaN 8
0 1 4 6 NaN 8 5 9 3 3 3 2
NaN 8 5 9 3 3 3 2 9 0 1 2
1 NaN NaN 9 3 3 3 2 9 NaN 1 2
9 2 8 3 5 7 0 1 4 6 NaN 1];
[noNaN,oneNaN,moreNaN,naNloc,NewNaNs] = ProcessAllUPC_(ORIGINAL);
disp(['Total number with 0 NaN is: ' num2str(nNaN)])
disp(['Total number with more than 1 NaN is: ' num2str(MoreNaN)])
disp(['Total number with 1 NaN is: ' num2str(OneNaN)])
disp(['They are located in row(s): ' num2str(NaNloc)])