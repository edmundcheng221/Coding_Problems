function [noNaN,oneNaN,moreNaN,naNloc,NewNaNs] = ProcessAllUPC_(ORIGINAL)
[nRow, nCol] = size(ORIGINAL);
noNaN = 0;
oneNaN = 0;
moreNaN = 0;
naNloc = zeros(1,nRow);
Originalcode = [];
    for i = 1: nRow
        [nanNumber, compValue, NewNaNs] = Process1UPC_(ORIGINAL(i,:));
        if nanNumber == 0
        noNaN = noNaN +1;
        NewNaNs = ORIGINAL(i,:);
        elseif nanNumber ==1
        oneNaN = oneNaN + 1;
        naNloc(i) = 1;
        else
        moreNan = moreNan + 1;
        NewNaNs = ORIGINAL(i,:);
        end
        NewNaNs = [Originalcode; NewNaNs];
        Originalcode = NewNaNs;
    end
    naNloc = find(naNLoc);
end
