function [compValue] = missingDigitAtEvenPosition_(theSum)
    compValue = (10* ceil(theSum/10) - theSum);
end