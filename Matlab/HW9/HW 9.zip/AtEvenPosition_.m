function [isEven] = AtEvenPosition_(nanIdx)
        isEven = ~mod(nanIdx,2);
end 

