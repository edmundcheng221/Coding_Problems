function [compValue] = Fix1UPC_(theSum,nanIdx)
    if AtEvenPosition_(nanIdx)
        compValue = missingDigitAtEvenPosition_(theSum);
    else
        compValue = missingDigitAtOddPosition_(theSum);
    end
end

