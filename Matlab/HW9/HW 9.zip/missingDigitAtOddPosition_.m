function [compValue] = missingDigitAtOddPosition_(theSum)
    compValue = mod(3* theSum, 10);
end

