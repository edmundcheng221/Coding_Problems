%% Problem 1
clear; clc; format short;
kMax = 4;
Uppercase = input('Enter a string of uppercase letters and digits','s');
[initialloc,atleastk] = Consecutiveletters_(Uppercase,kMax);
if atleastk == true
    disp(['Has at least' num2str(kMax) 'consecutive letters or digits'])
    disp(['Starting at location:' num2str(initialloc)])
else
    disp(['Less than' num2str(kMax) 'consecutive letters or digits:'])
    disp(['The value of the second output has no meaning'])
end