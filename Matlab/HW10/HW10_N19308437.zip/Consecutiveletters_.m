function [initialloc,atleastk] = Consecutiveletters_(Uppercase,kMax)
stringlength = length(Uppercase);
consecutiveletters = 0;
atleastk = false;
i = 1;

while (consecutiveletters < kMax) && (i < stringlength)
    i = i + 1;
        firstString = double(Uppercase(i));
            nextString = double(Uppercase(i-1));
        if firstString == nextString + 1
            consecutiveletters = consecutiveletters + 1;
            if consecutiveletters >= kMax
                atleastk = true;
                finalaccend = consecutiveletters;
                initialloc = i - finalaccend;
            elseif consecutiveletters < kMax
                initialloc = 0;
            end
        else 
            consecutiveletters = 1;
        end
end
end