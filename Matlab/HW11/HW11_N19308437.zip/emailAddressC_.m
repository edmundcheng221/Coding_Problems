function [EmailStructure] = emailAddressC_(LoginName, DomainName)
    EmailStructure.LoginName = LoginName;
    EmailStructure.DomainName = DomainName;
end