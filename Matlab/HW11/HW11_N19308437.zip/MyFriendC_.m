function [FriendStructure] = MyFriendC_(Name, Dob, LoginName, DomainName)
    FriendStructure.Name = Name;
    FriendStructure.Dob = Dob;
    FriendStructure.EmailAddress = emailAddressC_(LoginName, DomainName);
end
