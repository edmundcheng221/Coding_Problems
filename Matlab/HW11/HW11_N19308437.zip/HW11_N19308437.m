%% Edmund Cheng N19308437
%% Problem 1
clear; clc; format short;
load Friends.mat
todaydate = now;
[numRows,numFriends] = size(MyFriends);
NYUNameList = [];
ageLimit = 21;
nDays = 364.24;
nyu = 'nyu.edu';
for i = 1:numFriends
    dobFriend = MyFriends(i).Dob;
    nAge = (todaydate - dobFriend)/nDays;
    theSchool = MyFriends(i).EmailAddress.DomainName;
    if nAge >=ageLimit && strcmp(theSchool, nyu)
        newLoginName = MyFriends(i).Name;
        NYUNameList = strvcat(NYUNameList, newLoginName);
    end
end
disp('This is the list of my NYU friends who are of legal drinking age:')
disp(NYUNameList)
